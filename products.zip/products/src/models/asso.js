// import Category from "./categoryModel.js";
import Inventory from "./inventoryModel.js";
import sequelize from "../config/database.js";
// import Product from "./productModel.js";

// Category.hasMany(Product, { foreignKey: 'category_id' });
// Product.belongsTo(Category);

// Product.hasMany(Inventory, { foreignKey: "product_id" });
// Inventory.belongsTo(Product);

const initDB = async () => {
    try{
        await sequelize.authenticate();
        console.log("Conexión establecida correctamente.");
        // await Category.sync({force: true});
        // await Product.sync({force: true});
        await Inventory.sync({force: true});
        
    } catch(err) {
        console.error('Unable to connect to the database:', err);
    }
};

export default initDB;