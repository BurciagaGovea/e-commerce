import express from "express";
import bodyParser from "body-parser";
import router from "./routes/categoryRoutes.js";

const app = express();

app.use(bodyParser.json());
app.use('/api/products', router);

export default app;