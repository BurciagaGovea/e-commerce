import express from "express";
import { getCategories, createCategory } from "../controllers/categoryController.js";

const router = express.Router();

router.get('/categories', getCategories);

router.post('/createcCategory', createCategory);

export default router;